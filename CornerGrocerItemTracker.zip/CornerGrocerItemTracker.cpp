#include <iostream>
#include <fstream>
#include <map>
#include <string>

class ItemTracker {
private:
    std::map<std::string, int> itemFrequency;  // To store the frequency of each item

public:
    // Method to read the input file and populate the item frequencies
    void readFile(const std::string& filename) {
        std::ifstream inputFile(filename);
        std::string item;

        if (inputFile.is_open()) {
            while (inputFile >> item) {
                itemFrequency[item]++;
            }
            inputFile.close();
        }
        else {
            std::cerr << "Unable to open file: " << filename << std::endl;
        }
    }

    // Method to get the frequency of a specific item
    int getItemFrequency(const std::string& item) {
        if (itemFrequency.find(item) != itemFrequency.end()) {
            return itemFrequency[item];
        }
        return 0;  // Return 0 if item not found
    }

    // Method to display all items and their frequencies
    void displayAllItems() {
        std::cout << "Item Frequency List:\n";
        for (const auto& pair : itemFrequency) {
            std::cout << pair.first << ": " << pair.second << std::endl;
        }
    }

    // Method to display a histogram of item frequencies
    void displayHistogram() {
        std::cout << "Item Frequency Histogram:\n";
        for (const auto& pair : itemFrequency) {
            std::cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++) {
                std::cout << "*";
            }
            std::cout << std::endl;
        }
    }

    // Method to save data to frequency.dat (for backup)
    void saveData() {
        std::ofstream outputFile("frequency.dat");
        if (outputFile.is_open()) {
            for (const auto& pair : itemFrequency) {
                outputFile << pair.first << " " << pair.second << std::endl;
            }
            outputFile.close();
            std::cout << "Data saved to frequency.dat successfully.\n";
        }
        else {
            std::cerr << "Unable to open frequency.dat for writing.\n";
        }
    }
};

// Function to display the menu options
void showMenu() {
    std::cout << "\n----- Menu -----\n";
    std::cout << "1. Search for item frequency\n";
    std::cout << "2. Display all items and frequencies\n";
    std::cout << "3. Display histogram of item frequencies\n";
    std::cout << "4. Exit\n";
    std::cout << "Enter your choice: ";
}

int main() {
    ItemTracker tracker;

    // Load the input file (CS210_Project_Three_Input_File.txt) to populate item frequencies
    tracker.readFile("CS210_Project_Three_Input_File.txt");

    // Save the item data to a backup file (frequency.dat)
    tracker.saveData();

    int choice;
    std::string item;

    // Main program loop
    while (true) {
        showMenu();  // Display the menu options
        std::cin >> choice;

        switch (choice) {
        case 1:
            // Menu option 1: Search for a specific item frequency
            std::cout << "Enter item name: ";
            std::cin >> item;
            std::cout << item << " was purchased " << tracker.getItemFrequency(item) << " times.\n";
            break;
        case 2:
            // Menu option 2: Display all items and their frequencies
            tracker.displayAllItems();
            break;
        case 3:
            // Menu option 3: Display a histogram of item frequencies
            tracker.displayHistogram();
            break;
        case 4:
            // Menu option 4: Exit the program
            std::cout << "Exiting program.\n";
            return 0;
        default:
            // Handle invalid menu input
            std::cout << "Invalid choice. Please try again.\n";
            break;
        }
    }

    return 0;
}

